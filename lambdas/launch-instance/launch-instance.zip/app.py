import boto3
import os

ec2 = boto3.client('ec2')

def lambda_handler(event, context):
    image_id = event.get('ImageId')
    if not image_id:
        raise Exception("ImageId required")

    # Force free-tier instance type
    instance_type = "t2.micro"

    # Do NOT re-use instance info from source
    response = ec2.run_instances(
        ImageId=image_id,
        InstanceType=instance_type,
        MinCount=1,
        MaxCount=1,
        KeyName=os.environ.get("KEY_NAME"),
        NetworkInterfaces=[{
            "AssociatePublicIpAddress": True,
            "DeviceIndex": 0,
            "SubnetId": os.environ.get("SUBNET_ID"),
            "Groups": [os.environ.get("SG_ID")]
        }]
    )

    return {
        "InstanceId": response["Instances"][0]["InstanceId"]
    }
